<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', '192.168.110.148');
define('UC_DBUSER', 'root');
define('UC_DBPW', '123456');
define('UC_DBNAME', 'moresec');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`discuz`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'T3Z7V6w2U0vf56t9xcbcI0v9YfHaffk0ScJ4u277j6z7Ffg2RcA1i5m8v3haH0ue');
define('UC_API', 'http://x');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);