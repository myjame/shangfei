<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 26ded374df110920701de8ef98598dfc

$pluginsetting = array (
);
?>