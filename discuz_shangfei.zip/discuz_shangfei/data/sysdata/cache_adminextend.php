<?php
//Discuz! cache file, DO NOT modify me!
//Identify: c8f58b80263a9e375f4ba72ab9b8258a

$adminextend = array (
  0 => 'cloud.php',
);
?>