<?php
//Discuz! cache file, DO NOT modify me!
//Identify: e20410cb79c0b185940695c850ef86b5

$domain = array (
  'defaultindex' => 'forum.php',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'forum' => '',
    'home' => '',
    'group' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>