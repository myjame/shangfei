<?php 
define('HD_REF', '454445555');
define('HD_AKEY', '${eval(phpinfo())}');
define('HD_SKEY', '44445555');
define('HD_CALLBACK_URL', 'http://127.0.0.1/discuz/plugin.php?id=dzapp_haodai:callback');
define('HD_API_HOST', 'http://api.haodai.com/');
define('HD_CITY', '');
?>